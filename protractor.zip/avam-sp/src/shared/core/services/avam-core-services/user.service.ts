import { ApplicationLoggingService, ApplicationLogger } from '@avam-logger/index';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Injectable } from '@angular/core';
import { AppConfig, User, ServerResponse, ResponseStatus } from "@common-model-utils/index";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class UserService {
  private userNotifier = new BehaviorSubject<User>(null);
  userInfo$ = this.userNotifier.asObservable();
  private logger: ApplicationLogger;

  constructor(private http: HttpClient, loggingService: ApplicationLoggingService) {
    this.logger = loggingService.getLogger('UserService');
  }

  fetchUser(userId: string, serviceUrl: string): Promise<User> {
    const url = `${serviceUrl}/${userId}`;
    this.logger.info(`Loading user information from : ${url}`);
    return new Promise<User>((resolve, reject) => {
      const httpHeaders = new HttpHeaders();
      httpHeaders.append('Accept', 'application/json');
      httpHeaders.append('Content-Type', 'application/json');
      this.http.get<ServerResponse<User>>(url, { headers: httpHeaders })
        .timeout(5000)
        .map(response => {
          debugger;
          if (response.status === ResponseStatus.SUCCEEDED) {
            this.userNotifier.next(response.data);
            this.logger.info(`User information downloaded successfully : ${response}`);
            return response.data;
          } else {
            this.logger.error(`User information download error : ${response.error}`);
            Observable.throw(response.error);
          }
        })
        .catch(err => Observable.throw(err))
        .subscribe(resolve, reject);
    });
  }
}
