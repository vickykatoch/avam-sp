import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { ApplicationLoggingService, ApplicationLogger } from '@avam-logger/index';
import { Injectable } from '@angular/core';

@Injectable()
export class UserPreferenceService {
  private logger : ApplicationLogger;
  private userPrefs : any;

  constructor(loggingService : ApplicationLoggingService, private http: HttpClient) { 
    this.logger = loggingService.getLogger('UserPreferenceService');
  }

  fetchUserPreferences(url: string, timeout?: number) : Promise<boolean> {
    return new Promise<boolean>((resolve,reject)=> {
      timeout = timeout || 30000;
      this.http.get<any>(url)
          .timeout(timeout)
          .catch(error=> Observable.throw(error))
          .map(prefs=> this.userPrefs = prefs)
          .subscribe(x=> { 
            resolve(true); 
          }, error=> {
            reject(error);
          });
    });
  }

}
