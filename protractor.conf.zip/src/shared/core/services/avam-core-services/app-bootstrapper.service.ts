import { Subject } from 'rxjs/Subject';
import { ConfigurationService } from './configuration.service';
import { UserService } from './user.service';
import { ApplicationInfo, CommonUtils, CoreModelHelper } from '@common-model-utils/index';
import { Injectable } from '@angular/core';



@Injectable()
export class AppBootstrapperService {

  constructor(private userService: UserService, private configService: ConfigurationService) {

  }
  bootstrap(user: string, region: string, env: string): void {
    // this.validateAppInfo(appInfo);
    this.configService.getConfig(region, env).then(appConfig => {
      console.log(appConfig);
      this.userService.authenticate(user, appConfig.api.userInfoServiceUrl).then(user=> {
        
        console.log(user);
      })
    },console.warn).catch(console.error);
  }

  // #region Helper Methods
  private validateAppInfo(appInfo: ApplicationInfo) {
    let errorMessage = '';
    CoreModelHelper.instance.appInfoHelper.mandatoryProps.forEach(propName => {
      if (CommonUtils.instance.isStringNullOrEmpty(appInfo[propName])) {
        errorMessage = `${errorMessage}${propName} is empty, `;
      }
    });
    CommonUtils.instance.throwIfTrue(!CommonUtils.instance.isStringNullOrEmpty(errorMessage), errorMessage);
  }
  
  // #endregion
}
