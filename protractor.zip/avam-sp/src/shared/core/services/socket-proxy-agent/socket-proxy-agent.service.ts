import { Injectable } from '@angular/core';



@Injectable()
export class SocketProxyAgentService {

  constructor() { 

  }

  

}
