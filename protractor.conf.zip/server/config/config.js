const cfg = {
      port : 8000
};

module.exports = cfg;