
export interface Role {
    name                : string;
    isAdmin             : boolean;
    description         : string;
    isActive            : string;
}

export interface Resource {
    name                : string;
    caption             : string;
    type                : string; // Type of resource i.e Menu, display Item
    isActive            : boolean;
    icon?               : string;
    path?               : string;
    parent?             : string;
    target?             : string;         
}

export interface RoleResource {
    role                : string;
    resources           : {[resourceName : string] : number }; // Where resourceName is name of the resource and value is permissions on the resource 
}

export interface User {
    userId              : string;
    name                : string;
    roleResources       : { [roleName : string] : RoleResource };
}



