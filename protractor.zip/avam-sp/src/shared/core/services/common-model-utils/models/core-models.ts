export interface ApplicationInfo {
      name              : string;
      user              : string;
      type              : string;
      env               : string;
      region            : string;
      version           : string;      
}

export const MAIN_APP_NAME = "AVAM-MAIN-APP";

export interface ServerResponse<T> {
      status            : number;
      data              : T;
      error?            : any;
}
export const ResponseStatus = Object.freeze({
   SUCCEEDED            : 200   
});



