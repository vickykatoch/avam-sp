export interface AppConfig {
    api                             : ApiConfig;
}

export interface ApiConfig {
    userPreferenceServiceUrl                          : string;
    workspaceServiceUrl                               : string;
    userInfoServiceUrl                                : string;
}