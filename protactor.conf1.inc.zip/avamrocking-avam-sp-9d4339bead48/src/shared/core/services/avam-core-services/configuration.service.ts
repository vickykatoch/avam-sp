import { Observable } from 'rxjs/Observable';
import { AppConfig } from './../common-model-utils/models/config-models';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Injectable } from '@angular/core';
import * as jsyaml from 'js-yaml';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ConfigurationService {
  private appConfigNotifier = new BehaviorSubject<AppConfig>(null);
  private appConfig: AppConfig;

  constructor(private http: HttpClient) {
  }

  getConfig(region: string, env: string): Promise<AppConfig> {
    const url = `${window.location.origin}/api/appConfigs/${region}/${env}`;
    return new Promise<AppConfig>((resolve, reject) => {
      this.http.get(url, { responseType: 'text' })
        .map(config => {
          this.appConfig = jsyaml.load(config);
          return this.appConfig;
        }).subscribe(resolve, reject);
    });
  }
}
