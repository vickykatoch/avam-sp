import { ApplicationLoggingService, ApplicationLogger } from '@avam-logger/index';
import { Subject } from 'rxjs/Subject';
import { ConfigurationService } from './configuration.service';
import { UserService } from './user.service';
import { ApplicationInfo, CommonUtils, CoreModelHelper } from '@common-model-utils/index';
import { Injectable } from '@angular/core';



@Injectable()
export class AppBootstrapperService {
  private logger : ApplicationLogger;
  private Assert =  CommonUtils.instance.throwIfTrue;

  constructor(private userService: UserService, private configService: ConfigurationService,
              loggingService: ApplicationLoggingService) {
        this.logger = loggingService.getLogger('AppBootstrapperService');
  }

  bootstrap(user: string, region: string, env: string): void {
    this.Assert(!user || user.trim().length===0, 'Empty user id');
    this.Assert(!region || region.trim().length===0, 'Region is empty');
    this.Assert(!env || env.trim().length===0, 'Application enviroment is empty');

    this.logger.info(`Application is bootstrapping, Region : ${region}, ${user}, ${env}`);
    this.configService.getConfig(region, env).then(appConfig => {
      this.userService.fetchUser(user, appConfig.api.userInfoServiceUrl).then(user=> {
        console.log('Success');
      }).catch(err=> {
        debugger;
        this.logger.error(err);
      });
    },console.warn).catch(this.logger.error);
  }

  // #region Helper Methods
  
  
  // #endregion
}
